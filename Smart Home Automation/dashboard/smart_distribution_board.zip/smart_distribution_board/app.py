import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime
import time

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Smart Distribution Board",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Inject custom CSS to match the original dashboard ─────────────────────────
st.markdown("""
<style>
/* Import Google Font */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

/* ── Global ── */
html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* Hide Streamlit default header/footer */
#MainMenu, footer, header { visibility: hidden; }

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background-color: #0f172a !important;
    color: white !important;
}
[data-testid="stSidebar"] .stRadio label,
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span {
    color: #cbd5e1 !important;
    font-size: 14px;
}
[data-testid="stSidebar"] .stRadio > div {
    gap: 4px;
}
/* Active nav item */
[data-testid="stSidebar"] .stRadio label:hover {
    color: white !important;
}

/* ── Top metric cards ── */
.metric-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    display: flex;
    align-items: center;
    gap: 16px;
    min-height: 100px;
}
.metric-icon {
    width: 52px;
    height: 52px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    flex-shrink: 0;
}
.metric-value { font-size: 28px; font-weight: 700; color: #1e293b; line-height: 1.1; }
.metric-label { font-size: 12px; color: #94a3b8; margin-top: 3px; }
.metric-title { font-size: 13px; font-weight: 600; margin-bottom: 2px; }

/* ── Section cards ── */
.section-card {
    background: white;
    border-radius: 12px;
    padding: 20px 22px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    height: 100%;
}
.section-title { font-size: 15px; font-weight: 700; color: #1e293b; margin-bottom: 14px; }

/* ── PZEM table rows ── */
.pzem-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 7px 0;
    border-bottom: 1px solid #f1f5f9;
    font-size: 13.5px;
}
.pzem-row:last-child { border-bottom: none; }
.pzem-row .label { color: #475569; display: flex; align-items: center; gap: 8px; }
.pzem-row .value { font-weight: 600; color: #1e293b; }

/* ── Appliance status card ── */
.appliance-row {
    background: #f8fafc;
    border-radius: 10px;
    padding: 12px 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}
.badge-on  { background:#22c55e; color:white; padding:2px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.badge-off { background:#ef4444; color:white; padding:2px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.green { color: #22c55e; font-weight: 700; }
.ts { font-size: 11px; color: #94a3b8; margin-top: 4px; }

/* ── Power Source card ── */
.source-row {
    background: #f8fafc;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 10px;
}
.badge-avail { background:#dcfce7; color:#16a34a; padding:2px 10px; border-radius:20px; font-size:11px; font-weight:600; }
.source-metrics { font-size: 13px; color: #475569; margin-top: 6px; display:flex; justify-content:space-between; }
.info-banner {
    background: #eff6ff;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 13px;
    color: #2563eb;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 6px;
}

/* ── Quick Control ── */
.qc-card {
    background: white;
    border-radius: 12px;
    padding: 20px 22px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.08);
}
.btn-on  { background:#22c55e !important; color:white !important; border:none !important;
           border-radius:6px !important; padding:8px 22px !important; font-weight:600 !important; }
.btn-off { background:#ef4444 !important; color:white !important; border:none !important;
           border-radius:6px !important; padding:8px 22px !important; font-weight:600 !important; }
.sched-btn {
    background: #2563eb;
    color: white;
    border-radius: 8px;
    padding: 12px;
    text-align: center;
    font-weight: 600;
    font-size: 14px;
    margin-top: 14px;
    cursor: pointer;
}

/* ── System status ── */
.status-online {
    background: #064e3b;
    border-radius: 10px;
    padding: 12px 14px;
    color: white;
}
.dot-green { width:10px; height:10px; background:#22c55e; border-radius:50%; display:inline-block; margin-right:6px; }

/* ── Main bg ── */
.main .block-container { background: #f1f5f9; padding-top: 1.5rem; }

/* ── Topbar ── */
.topbar {
    background: white;
    border-radius: 12px;
    padding: 12px 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.topbar-title { font-size: 20px; font-weight: 700; color: #1e293b; }
.topbar-right  { font-size: 13px; color: #64748b; display: flex; gap: 20px; align-items:center; }
</style>
""", unsafe_allow_html=True)

# ── Session state for toggle switches ──────────────────────────────────────────
if "bulb_on" not in st.session_state:
    st.session_state.bulb_on = True
if "fan_on" not in st.session_state:
    st.session_state.fan_on = True
if "page" not in st.session_state:
    st.session_state.page = "Dashboard"

# ── Simulated live data (replace with real PZEM / MQTT / serial reads) ─────────
def get_live_data():
    return {
        "voltage":        229.6,
        "current":        2.35,
        "active_power":   482.7,
        "apparent_power": 540.3,
        "power_factor":   0.89,
        "frequency":      50.02,
        "energy_total":   125.36,
        "energy_today":   2.48,
        "bulb_current":   0.58,
        "bulb_power":     61.3,
        "fan_current":    1.77,
        "fan_power":      187.6,
        "src1_voltage":   229.8,
        "src1_freq":      50.01,
        "src2_voltage":   230.1,
        "src2_freq":      50.02,
    }

def power_trend_data():
    """Simulated 24-hour power trend."""
    hours = np.linspace(0, 24, 100)
    base  = 300
    trend = (base
             + 200 * np.sin(np.pi * hours / 12)
             + np.random.normal(0, 30, 100))
    trend = np.clip(trend, 150, 800)
    return hours, trend

# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    # Logo area
    st.markdown("""
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0 24px 0;">
      <div style="background:#f59e0b;border-radius:10px;width:42px;height:42px;
                  display:flex;align-items:center;justify-content:center;font-size:20px;">⚡</div>
      <div>
        <div style="color:white;font-weight:700;font-size:15px;line-height:1.2;">Smart Distribution</div>
        <div style="color:#94a3b8;font-size:12px;">Board</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    nav_items = {
        "Dashboard":      "🏠",
        "Energy Monitor": "📈",
        "Appliances":     "🔌",
        "Scheduling":     "📅",
        "Power Sources":  "🗼",
        "Logs":           "📋",
        "Settings":       "⚙️",
    }

    for label, icon in nav_items.items():
        active = st.session_state.page == label
        bg = "#2563eb" if active else "transparent"
        txt = "white" if active else "#94a3b8"
        if st.button(f"{icon}  {label}", key=f"nav_{label}",
                     use_container_width=True):
            st.session_state.page = label
            st.rerun()

    # System status
    st.markdown("<div style='height:30px'></div>", unsafe_allow_html=True)
    now_str = datetime.now().strftime("%I:%M:%S %p")
    st.markdown(f"""
    <div class="status-online">
      <div style="font-size:12px;color:#86efac;margin-bottom:4px;">
        <span class="dot-green"></span>System Status
      </div>
      <div style="font-size:18px;font-weight:700;color:#22c55e;">Online</div>
      <div style="font-size:11px;color:#6ee7b7;margin-top:4px;">Last Update: {now_str}</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
    st.markdown("""
    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;">
      <div style="background:#334155;border-radius:50%;width:36px;height:36px;
                  display:flex;align-items:center;justify-content:center;font-size:16px;">👤</div>
      <div>
        <div style="color:white;font-size:13px;font-weight:600;">User</div>
        <div style="color:#94a3b8;font-size:11px;">Admin</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════════════════════
# DASHBOARD PAGE
# ═══════════════════════════════════════════════════════════════════════════════
if st.session_state.page == "Dashboard":
    data = get_live_data()
    now_str = datetime.now().strftime("%I:%M:%S %p")

    # ── Top bar ────────────────────────────────────────────────────────────────
    st.markdown(f"""
    <div class="topbar">
      <div class="topbar-title">Dashboard</div>
      <div class="topbar-right">
        <span>📶 Wi-Fi Connected</span>
        <span>🕐 {now_str}</span>
        <span>🔔</span>
      </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Metric cards (top row) ─────────────────────────────────────────────────
    c1, c2, c3, c4 = st.columns(4)

    metrics = [
        (c1, "#eff6ff", "#2563eb", "⚡", "Voltage",      f"{data['voltage']} V",   "AC Voltage",      "#2563eb"),
        (c2, "#f0fdf4", "#22c55e", "📈", "Current",      f"{data['current']} A",   "AC Current",      "#22c55e"),
        (c3, "#fff7ed", "#f97316", "⏱️", "Active Power", f"{data['active_power']} W", "Power",        "#f97316"),
        (c4, "#f5f3ff", "#7c3aed", "📊", "Energy Today", f"{data['energy_today']} kWh", "Energy Consumed", "#7c3aed"),
    ]

    for col, bg, accent, icon, title, value, sublabel, color in metrics:
        with col:
            st.markdown(f"""
            <div class="metric-card">
              <div class="metric-icon" style="background:{bg};">
                <span style="font-size:22px;">{icon}</span>
              </div>
              <div>
                <div class="metric-title" style="color:{color};">{title}</div>
                <div class="metric-value">{value}</div>
                <div class="metric-label">{sublabel}</div>
              </div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)

    # ── Middle row: PZEM | Appliance Status | Power Source ────────────────────
    col_pzem, col_app, col_src = st.columns([1.2, 1.1, 1.1])

    # — PZEM-004T table —
    with col_pzem:
        pzem_rows = [
            ("⚡", "Voltage",        f"{data['voltage']} V"),
            ("〰️", "Current",        f"{data['current']} A"),
            ("⏱", "Active Power",   f"{data['active_power']} W"),
            ("VA","Apparent Power", f"{data['apparent_power']} VA"),
            ("Φ", "Power Factor",   f"{data['power_factor']}"),
            ("〜", "Frequency",      f"{data['frequency']} Hz"),
            ("🔢","Energy Total",   f"{data['energy_total']} kWh"),
        ]
        rows_html = "".join([
            f'<div class="pzem-row"><span class="label"><span>{icon}</span>{label}</span>'
            f'<span class="value">{val}</span></div>'
            for icon, label, val in pzem_rows
        ])
        st.markdown(f"""
        <div class="section-card">
          <div class="section-title">Energy Monitoring (PZEM-004T)</div>
          {rows_html}
        </div>
        """, unsafe_allow_html=True)

    # — Appliance Status —
    with col_app:
        b_badge = '<span class="badge-on">ON</span>'  if st.session_state.bulb_on  else '<span class="badge-off">OFF</span>'
        f_badge = '<span class="badge-on">ON</span>'  if st.session_state.fan_on   else '<span class="badge-off">OFF</span>'
        st.markdown(f"""
        <div class="section-card">
          <div class="section-title">Appliance Status</div>

          <div class="appliance-row">
            <div style="display:flex;align-items:center;gap:12px;">
              <span style="font-size:32px;">💡</span>
              <div>
                <div style="font-weight:700;font-size:15px;">Bulb</div>
                {b_badge}
              </div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:12px;color:#94a3b8;">Current</div>
              <div class="green">{data['bulb_current']} A</div>
              <div style="font-size:12px;color:#94a3b8;">Power</div>
              <div class="green">{data['bulb_power']} W</div>
            </div>
          </div>
          <div class="ts">Last Update: {now_str}</div>

          <div style="height:8px"></div>

          <div class="appliance-row">
            <div style="display:flex;align-items:center;gap:12px;">
              <span style="font-size:32px;">🌀</span>
              <div>
                <div style="font-weight:700;font-size:15px;">Fan</div>
                {f_badge}
              </div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:12px;color:#94a3b8;">Current</div>
              <div class="green">{data['fan_current']} A</div>
              <div style="font-size:12px;color:#94a3b8;">Power</div>
              <div class="green">{data['fan_power']} W</div>
            </div>
          </div>
          <div class="ts">Last Update: {now_str}</div>
        </div>
        """, unsafe_allow_html=True)

    # — Power Source Status —
    with col_src:
        st.markdown(f"""
        <div class="section-card">
          <div class="section-title">Power Source Status</div>

          <div class="source-row">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <div style="display:flex;align-items:center;gap:10px;">
                <span style="font-size:26px;color:#22c55e;">🗼</span>
                <span style="font-weight:700;font-size:14px;">Source 1 (Main)</span>
              </div>
              <span class="badge-avail">AVAILABLE</span>
            </div>
            <div class="source-metrics">
              <span>{data['src1_voltage']} V</span>
              <span>{data['src1_freq']} Hz</span>
            </div>
          </div>

          <div class="source-row">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <div style="display:flex;align-items:center;gap:10px;">
                <span style="font-size:26px;color:#f59e0b;">🗼</span>
                <span style="font-weight:700;font-size:14px;">Source 2 (Backup)</span>
              </div>
              <span class="badge-avail">AVAILABLE</span>
            </div>
            <div class="source-metrics">
              <span>{data['src2_voltage']} V</span>
              <span>{data['src2_freq']} Hz</span>
            </div>
          </div>

          <div class="info-banner">
            ℹ️ System is operating on Source 1 (Main)
          </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='height:14px'></div>", unsafe_allow_html=True)

    # ── Bottom row: Power Trend | Quick Control ────────────────────────────────
    col_chart, col_ctrl = st.columns([1.8, 1])

    # — Power Trend Chart —
    with col_chart:
        hours, power = power_trend_data()
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=hours, y=power,
            mode="lines+markers",
            line=dict(color="#2563eb", width=2.5),
            marker=dict(size=4, color="#2563eb"),
            name="Active Power (W)",
            fill="tozeroy",
            fillcolor="rgba(37,99,235,0.07)",
        ))
        fig.update_layout(
            title=dict(text="Power Trend (Today)", font=dict(size=14, color="#1e293b"), x=0),
            xaxis=dict(
                tickvals=[0,4,8,12,16,20,24],
                ticktext=["00:00","04:00","08:00","12:00","16:00","20:00","24:00"],
                showgrid=True, gridcolor="#f1f5f9", linecolor="#e2e8f0",
                title="", tickfont=dict(size=11),
            ),
            yaxis=dict(
                range=[0, 850], showgrid=True, gridcolor="#f1f5f9",
                title="Power (W)", tickfont=dict(size=11),
            ),
            plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=40, r=20, t=40, b=40),
            legend=dict(orientation="h", y=-0.15, x=0.35,
                        font=dict(size=11), bgcolor="white"),
            height=300,
        )
        st.markdown('<div class="section-card" style="padding-bottom:4px;">', unsafe_allow_html=True)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        st.markdown('</div>', unsafe_allow_html=True)

    # — Quick Control —
    with col_ctrl:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.markdown('<div class="section-title">Quick Control</div>', unsafe_allow_html=True)

        qc1, qc2 = st.columns(2)

        with qc1:
            st.markdown("💡 **Bulb**")
            b1, b2 = st.columns(2)
            with b1:
                if st.button("ON",  key="bulb_on_btn",
                             type="primary" if st.session_state.bulb_on else "secondary"):
                    st.session_state.bulb_on = True
                    st.rerun()
            with b2:
                if st.button("OFF", key="bulb_off_btn",
                             type="secondary" if st.session_state.bulb_on else "primary"):
                    st.session_state.bulb_on = False
                    st.rerun()

        with qc2:
            st.markdown("🌀 **Fan**")
            f1, f2 = st.columns(2)
            with f1:
                if st.button("ON",  key="fan_on_btn",
                             type="primary" if st.session_state.fan_on else "secondary"):
                    st.session_state.fan_on = True
                    st.rerun()
            with f2:
                if st.button("OFF", key="fan_off_btn",
                             type="secondary" if st.session_state.fan_on else "primary"):
                    st.session_state.fan_on = False
                    st.rerun()

        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        if st.button("📅  Go to Scheduling", use_container_width=True, type="primary"):
            st.session_state.page = "Scheduling"
            st.rerun()

        st.markdown('</div>', unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════════════════════
# OTHER PAGES (placeholders — extend as needed)
# ═══════════════════════════════════════════════════════════════════════════════
elif st.session_state.page == "Energy Monitor":
    st.title("📈 Energy Monitor")
    st.info("Connect your PZEM-004T data stream here and add historical charts.")

elif st.session_state.page == "Appliances":
    st.title("🔌 Appliances")
    st.info("Manage and add appliances connected to your distribution board.")

elif st.session_state.page == "Scheduling":
    st.title("📅 Scheduling")
    st.info("Set ON/OFF schedules for each appliance.")

elif st.session_state.page == "Power Sources":
    st.title("🗼 Power Sources")
    st.info("Monitor Source 1 (Main) and Source 2 (Backup) details.")

elif st.session_state.page == "Logs":
    st.title("📋 Logs")
    st.info("Event logs and historical readings will appear here.")

elif st.session_state.page == "Settings":
    st.title("⚙️ Settings")
    st.info("Configure thresholds, alerts, and device settings.")